

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Pembayaran</h1>
    </div>


    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if($errors->any()): ?>
                <div class="mb-5" roles="alert">
                    <div class="bg-red-500 text-white font-bold rounded-t px-4 py-2">
                        There's something wrong!
                    </div>
                    <div class="border border-t-0 border-red-400 rounded-b bg-red-100 px-4 py-3 text-red-700">
                        <p>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </p>
                    </div>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('dashboard.user.update', $user->id)); ?>"
                class="w-full" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group row">
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Username</label>
                        <input type="text"
                            value="<?php echo e(old('name') ?? $user->name); ?>"
                            name="name" class="form-control form-control-user" placeholder="No Pembayaran"
                            id="">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Email</label>
                        <input type="email"
                            value="<?php echo e(old('email') ?? $user->email); ?>"
                            email="email" class="form-control form-control-user" placeholder="No Pembayaran"
                            id="">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-6 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Roles</label>
                        <select name="roles" id="nisn" class="form-control form-control-user">
                            <option
                                value="<?php echo e(old(' $user->roles') ?? $user->roles); ?>">
                                <?php echo e($user->roles); ?></option>
                            <option value="">---------------</option>

                            <option value="ADMIN">ADMIN</option>
                            <option value="USER">USER</option>

                        </select>
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Status</label>
                        <select name="status" id="nisn" class="form-control form-control-user">
                            <option
                                value="<?php echo e(old(' $user->status') ?? $user->status); ?>">
                                <?php echo e($user->status); ?></option>
                            <option value="">---------------</option>

                            <option value="ACTIVE">ACTIVE</option>
                            <option value="INACTIVE">INACTIVE</option>
                        </select>
                    </div>
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-primary">
                            Save Class
                        </button>
                    </div>
                </div>
                
            </form>
        </div>
    </div>

</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\misutasv1\resources\views/pages/dashboard/admin/user/edit.blade.php ENDPATH**/ ?>