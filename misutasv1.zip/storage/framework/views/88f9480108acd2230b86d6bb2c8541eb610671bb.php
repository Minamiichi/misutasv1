

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Edit Pembayaran</h1>
    </div>


    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if($errors->any()): ?>
                <div class="mb-5" roles="alert">
                    <div class="bg-red-500 text-white font-bold rounded-t px-4 py-2">
                        There's something wrong!
                    </div>
                    <div class="border border-t-0 border-red-400 rounded-b bg-red-100 px-4 py-3 text-red-700">
                        <p>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </p>
                    </div>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('dashboard.payment.update', $payment->id)); ?>"
                class="w-full" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group row">
                    <div class="col-sm-12 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">No
                            Pembayaran</label>
                        <input type="text"
                            value="<?php echo e(old('no_pembayaran') ?? $payment->no_pembayaran); ?>"
                            name="no_pembayaran" class="form-control form-control-user" placeholder="No Pembayaran"
                            id="">
                    </div>
                    <div class="col-sm-12 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">NISN</label>
                            <input type="text" value="<?php echo e(old('name') ?? $payment->name); ?>" name="name"
                            class="form-control form-control-user" placeholder="Nama Siswa" id="">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-12 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Tanggal
                            Pembayaran</label>
                        <input type="date" value="<?php echo e(old('date') ?? $payment->date); ?>"
                            name="date" class="form-control form-control-user"
                            placeholder="Tanggal Pembayaran Pembayaran" id="">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">NISN</label>
                        <select name="category" id="nisn" class="form-control form-control-user">
                            <option
                                value="<?php echo e(old(' $payment->category') ?? $payment->category); ?>">
                                <?php echo e($payment->category); ?></option>
                            <option value="">---------------</option>

                            <option value="KAS">KAS</option>
                            <option value="SPP">SPP</option>

                        </select>
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Status</label>
                        <select name="status" id="status" class="form-control form-control-user">
                            <option value="<?php echo e(old('$payment->status') ?? $payment->status); ?>"><?php echo e($payment->status); ?></option>
                            <option value="">---------------</option>

                            <option value="SUCCESS">SUCCESS</option>
                            <option value="UNSUCCESS">UNSUCCESS</option>
                            
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-12 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Jumlah
                            Pembayaran</label>
                        <input type="text" value="<?php echo e(old('sum') ?? $payment->sum); ?>"
                            name="sum" class="form-control form-control-user" placeholder="Jumlah Pembayaran" id="">
                    </div>
                </div>
                <div class="col-lg-12">
                    <button type="submit" class="btn btn-primary">
                        Save Class
                    </button>
                </div>
            </form>
        </div>
    </div>

</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\misutasv1\resources\views/pages/dashboard/admin/payment/edit.blade.php ENDPATH**/ ?>