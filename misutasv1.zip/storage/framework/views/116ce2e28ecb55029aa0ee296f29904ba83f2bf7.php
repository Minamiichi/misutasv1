<div class="row">
    <div class="col-md-12">
        <div class="copyright">
            <p>Copyright © 2022 Minamiichi. All rights reserved. Template by <a href="https://colorlib.com">Colorlib</a>.</p>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\misutasv1\resources\views/components/admin/footer.blade.php ENDPATH**/ ?>