

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Tambah Siswa</h1>
    </div>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-12 lg:px-8">
            <form action="<?php echo e(route('dashboard.student.store')); ?>" class="w-full" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group row">
                    <div class="col-sm-6 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">NISN</label>
                        <input type="text" value="<?php echo e(old('nisn')); ?>" name="nisn"
                            class="form-control form-control-user" placeholder="NISN" id="">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">NIS</label>
                        <input type="text" value="<?php echo e(old('nis')); ?>" name="nis"
                            class="form-control form-control-user" placeholder="NIS" id="">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-12 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Nama
                            Siswa</label>
                        <input type="text" value="<?php echo e(old('name')); ?>" name="name"
                            class="form-control form-control-user" placeholder="Nama Siswa" id="">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Tempat
                            Lahir</label>
                        <input type="text" value="<?php echo e(old('born_place')); ?>" name="born_place"
                            class="form-control form-control-user" placeholder="Tempat Lahir" id="">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Tanggal
                            Lahir</label>
                        <input type="date" value="<?php echo e(old('birthdate')); ?>" name="birthdate"
                            class="form-control form-control-user" placeholder="Tanggal Lahir" id="">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Jenis
                            Kelamin</label>
                        <input type="text" value="<?php echo e(old('gender')); ?>" name="gender"
                            class="form-control form-control-user" placeholder="Jenis Kelamin" id="">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Agama</label>
                        <input type="text" value="<?php echo e(old('religion')); ?>" name="religion"
                            class="form-control form-control-user" placeholder="Agama" id="">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Status
                            dalam Keluarga</label>
                        <input type="text" value="<?php echo e(old('status')); ?>" name="status"
                            class="form-control form-control-user" placeholder="Status dalam Keluarga" id="">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Anak
                            Ke-</label>
                        <input type="text" value="<?php echo e(old('siblings')); ?>" name="siblings"
                            class="form-control form-control-user" placeholder="Anak Ke-" id="">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-12 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Alamat</label>
                        <input type="text" value="<?php echo e(old('address')); ?>" name="address"
                            class="form-control form-control-user" placeholder="Alamat" id="">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">No
                            Telepon</label>
                        <input type="text" value="<?php echo e(old('phone_number')); ?>" name="phone_number"
                            class="form-control form-control-user" placeholder="No Telepon" id="">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Sekolah
                            Asal</label>
                        <input type="text" value="<?php echo e(old('school')); ?>" name="school"
                            class="form-control form-control-user" placeholder="Sekolah Asal" id="">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-12 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Tanggal
                            diterima</label>
                        <input type="date" value="<?php echo e(old('accepted_date')); ?>" name="accepted_date"
                            class="form-control form-control-user" placeholder="Tanggal diterima" id="">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Nama
                            Ayah</label>
                        <input type="text" value="<?php echo e(old('father')); ?>" name="father"
                            class="form-control form-control-user" placeholder="Nama Ayah" id="">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Nama
                            Ibu</label>
                        <input type="text" value="<?php echo e(old('mother')); ?>" name="mother"
                            class="form-control form-control-user" placeholder="Nama Ibu" id="">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-6 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Pekerjaan
                            Ayah</label>
                        <input type="text" value="<?php echo e(old('father_jobs')); ?>" name="father_jobs"
                            class="form-control form-control-user" placeholder="Pekerjaan Ayah" id="">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Pekerjaan
                            Ibu</label>
                        <input type="text" value="<?php echo e(old('mother_jobs')); ?>" name="mother_jobs"
                            class="form-control form-control-user" placeholder="Pekerjaan Ibu" id="">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-6 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Nama
                            Wali</label>
                        <input type="text" value="<?php echo e(old('caregiver')); ?>" name="caregiver"
                            class="form-control form-control-user" placeholder="Nama Wali" id="">
                    </div>
                    <div class="col-sm-6 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Pekerjaan
                            Wali</label>
                        <input type="text" value="<?php echo e(old('caregiver_jobs')); ?>" name="caregiver_jobs"
                            class="form-control form-control-user" placeholder="Pekerjaan Wali" id="">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-sm-12 mb-3">
                        <label for="" class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Alamat
                            Wali</label>
                        <input type="text" value="<?php echo e(old('caregiver_address')); ?>"
                            name="caregiver_address" class="form-control form-control-user" placeholder="Alamat Wali"
                            id="">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-12 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Photo</label>
                        <input type="file" value="<?php echo e(old('url')); ?>" name="url"
                            class="form-control form-control-user" placeholder="Photo" id="">
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-12 mb-3">
                        <label for=""
                            class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2">Kelas</label>
                        <select name="room_id" id="" class="form-control form-control-user">
                            <option value="">Select Class</option>
                            <option value="">---------------</option>
                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="flex flex-wrap mx-3 mb-6">
                        <div class="w-full px-3">
                            <input type="hidden" value="secret" name="invisible"
                                class="block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500"
                                placeholder="Tanggal Lahir" id="">
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <button class="au-btn au-btn-icon au-btn--blue au-btn--small">
                            <i class="fa fa-save"></i>Save Data
                        </button>
                    </div>
                </div>
        </div>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\misutasv1\resources\views/pages/dashboard/admin/student/create.blade.php ENDPATH**/ ?>